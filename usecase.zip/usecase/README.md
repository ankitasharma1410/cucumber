# jSEPA

Includes IBAN validation by apache commons and a regular expression based validation for BICs. Strings are sanitized according to SEPA rules.

There is no national bank database lookup for IBAN and BIC validation, as that caused more harm than good in the past.