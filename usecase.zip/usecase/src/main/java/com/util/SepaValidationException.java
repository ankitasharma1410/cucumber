package com.util;

public class SepaValidationException extends Exception {
    public SepaValidationException(String message) {
        super(message);
    }
    
}
